__MODULE__ = "ʟɪᴍɪᴛ"
__HELP__ = """
<blockquote><b>♛ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʟɪᴍɪᴛ ♛<b>

<blockquote><b>perintah : 
<code>{0}limit</code> mengecek status akun apakah terkena limit atau tidak</b></blockquote>
"""
